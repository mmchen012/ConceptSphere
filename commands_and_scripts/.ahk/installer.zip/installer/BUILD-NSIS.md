# ConceptSphere-Setup-2.0.exe

A built, ready-to-run installer. Everything is inside it — the five exes, the
icon, `nvdaControllerClient64.dll`, the .ahk sources and `lib\`, and the two
PowerShell helpers. ~950 KB.

Built with NSIS 3.09 rather than Inno Setup, because `makensis` cross-compiles
Windows installers and Inno's compiler is Windows-only. The Inno script
(`ConceptSphereTools.iss`) still works and produces an equivalent installer if
you'd rather build it on your own machine.

## MiniTray build

The bundled `MiniTray.exe` is the post-sentinel build: `MTQUIET` and
`QuietPlugin` are present in the embedded script, `GagTick` is gone. It pairs
with the `minitrayQuiet` plugin in the add-on below -- install both, or set
`QuietPlugin=0` in `%APPDATA%\MiniTray\MiniTray.ini`, since without the plugin
NVDA reads the sentinel out loud.

Settings live in `%APPDATA%\MiniTray\MiniTray.ini`; the installer seeds the
existing rule set there without overwriting, and on first run the script also
migrates any `MiniTray.ini` found beside the exe.

## What the checkboxes do

The components page has two groups:

- **Tools** — which exes to install. "Source scripts" is unchecked by default.
- **Run at logon (elevated scheduled task)** — which tools to register, plus
  "Start them now". A task section skips itself with a note in the log if its
  exe wasn't installed, so a mismatched selection can't produce a task pointing
  at nothing.

Above them, **"Remove existing scheduled tasks (clean install)"** runs the sweep
before anything is registered.

| Tool | Task name | Logon delay |
|---|---|---|
| MiniTray | `MiniTray` | 20 s |
| EnhancedStartMenu | `Enhanced Start Menu` | 0 s |
| ConsoleSelectAll | `Console Select All` | 0 s |
| ConceptSphereWatchdog | `ConceptSphere Watchdog` | 10 s |

Those task names are load-bearing: ConceptSphereWatchdog restarts each component
through its task, matching on the name in its COMPONENTS table.

ConceptSphereWatchdog supersedes StartMenuWatchdog — one process watching
EnhancedStartMenu, ConsoleSelectAll and MiniTray. It is stopped first during
install and uninstall, since it would otherwise restart whatever the installer
had just killed. The clean-install sweep and the uninstaller both remove a
leftover `Start Menu Watchdog` task from an earlier install.

## Rebuilding

On Windows, install NSIS and run from this folder:

```powershell
& "C:\Program Files (x86)\NSIS\makensis.exe" .\ConceptSphereTools.nsi
```

Expects `payload\` (your v2.0 contents) and `install\` (the two .ps1 helpers)
beside the .nsi. Output goes to `Output\`.

## Notes

- Unsigned, so SmartScreen will say "unknown publisher" the first time. Details
  → Run anyway, or sign it with a self-signed cert in Trusted Publishers.
- Silent install: `ConceptSphere-Setup-2.0.exe /S` takes the default selection
  (all tools except source, all logon tasks, clean sweep on). NSIS has no
  per-section switch equivalent to Inno's `/COMPONENTS`; if you need scripted
  partial installs, build with the Inno script instead.
- Uninstall: Start menu → Uninstall, or Apps & features. It unregisters the four
  tasks, kills the processes and removes the files —
  `%APPDATA%\MiniTray\MiniTray.ini` is deliberately left behind.
- The installer runs `PrepareToInstall`-equivalent stops before copying: every
  tool is ended and killed, watchdog first. Without that, an elevated running
  copy holds its exe open.
- Built and syntax-checked here, but not run on Windows — the first install is
  the real test. `%TEMP%\ConceptSphere-task-cleanup.log` and the installer's own
  details pane are where to look if a step misbehaves.
