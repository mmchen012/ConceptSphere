# Building ConceptSphere-Setup-2.0.exe locally

Building on your own machine is also the cleanest answer to the SmartScreen
"unrecognized app" box: that check only fires on files carrying a Mark of the
Web, and a file you compiled yourself has never been near the internet. No
signing, no `Unblock-File`, no prompt.

## 1. Install NSIS, once

```powershell
winget install NSIS.NSIS
```

Or the installer from nsis.sourceforge.io. `build.ps1` looks in both Program
Files locations and on PATH; pass `-MakeNsis` if yours is elsewhere.

## 2. Put this folder somewhere sensible

Alongside your v2.0 folder is tidiest:

```
D:\Dropbox\Private\ConceptSphere\commands_and_scripts\.ahk\
├── v2.0\                       ← your compiled tools + nvda_addon\
└── installer\                  ← this kit
    ├── build.ps1
    ├── ConceptSphereTools.nsi
    ├── addon\manifest.ini
    ├── install\Register-ConceptSphereTask.ps1
    └── install\Remove-ConceptSphereTasks.ps1
```

`payload\` and `Output\` are created by the build; nothing in them is worth
keeping or syncing.

## 3. Build

```powershell
cd D:\Dropbox\Private\ConceptSphere\commands_and_scripts\.ahk\installer
.\build.ps1
```

No elevation needed. It stages `payload\` from `v2.0`, repackages the
`.nvda-addon` from `v2.0\nvda_addon\globalPlugins`, runs makensis, and leaves
`Output\ConceptSphere-Setup-2.0.exe`.

Useful switches:

| Switch | Effect |
|---|---|
| `-Sign` | Authenticode-sign the result with `CN=ConceptSphere` |
| `-SkipAddon` | Reuse the existing `.nvda-addon` instead of repackaging |
| `-Source <path>` | Build from a different v2.0 folder |
| `-MakeNsis <path>` | Point at makensis.exe explicitly |

## What the script does that is easy to get wrong by hand

**The add-on zip is built entry by entry.** Entries must be at the archive root
and use forward slashes. `Compress-Archive` has written backslash separators
for subfolders, which NVDA's zipfile reader treats as part of the filename
rather than a folder — you get an add-on that installs and does nothing.

**`payload\MiniTray.ini` is guaranteed to exist.** The `.nsi` seeds it into
`%APPDATA%\MiniTray` without overwriting, so it only matters on a machine that
has never run MiniTray — but a missing `File` source is a compile error, not a
warning. The script prefers your live `%APPDATA%\MiniTray\MiniTray.ini`, falls
back to `MiniTray.ini` then `MiniTray.ini.migrated` in the source folder, and
writes a minimal default rather than failing.

**`payload\` is wiped and restaged every time.** A stale exe left in there is
exactly the trap where the source is current and the thing you installed is not.

## After changing something

| Changed | Do |
|---|---|
| An AHK script | Recompile it with Ahk2Exe into `v2.0\`, then `.\build.ps1` |
| An NVDA plugin | Just `.\build.ps1` — it repackages the add-on |
| The manifest (add-on version, `lastTestedNVDAVersion`) | Edit `addon\manifest.ini`, then `.\build.ps1` |
| A component, task name or delay | Edit `ConceptSphereTools.nsi`, then `.\build.ps1` |

Bump `version` in `addon\manifest.ini` whenever a plugin changes, or NVDA will
not see it as an upgrade. The filename in `ConceptSphereTools.nsi`
(`ADDONFILE`) and `build.ps1` (`$addonName`) both carry the version — change all
three together.

**Pause the watchdog before recompiling**: Ctrl+Alt+Shift+P. Otherwise a task
you stopped by hand looks like a crash, and it restarts the component under
your new build.

## If makensis complains

- *"File: failed opening file payload\..."* — the staging step could not find
  something in `v2.0\`. The script prints the exe list it staged; compare.
- *"Can't open output file"* — `Output\ConceptSphere-Setup-2.0.exe` is open, or
  Dropbox is syncing it. Retry.
- *unknown command / bad parameter around `x64compatible`* — NSIS older than
  3.08. Update, or change the two `Architectures` lines in the `.nsi`.
