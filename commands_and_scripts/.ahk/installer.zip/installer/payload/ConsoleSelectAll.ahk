#Requires AutoHotkey v2.0
#SingleInstance Force

; ConsoleSelectAll - Ctrl+Shift+A selects and copies the whole console buffer.
;
; TWO THINGS CHANGED FROM THE PREVIOUS VERSION
;
; 1. STUCK CTRL
;    The old script sent ^a and ^c while Ctrl+Shift were still physically
;    held down (they have to be -- they are the hotkey). AutoHotkey will not
;    release a modifier it believes the user is holding, so the Ctrl-down it
;    injected for ^a could outlive the keystroke: the log showed the next two
;    presses arriving as control+NVDA+f1 and control+windows+m.
;    Now the script waits for the hotkey to be let go before it sends
;    anything, and afterwards forces up any modifier that is logically down
;    while physically up.
;
; 2. THE "874 characters selected / unselected" CHATTER
;    Quiet() used to hammer nvdaController_cancelSpeech. Cancelling can only
;    ever INTERRUPT -- NVDA queues the announcement the instant the selection
;    changes, and with the dual-voice synth rendering on a background thread
;    the audio is already on its way out. Same wall MiniTray hit.
;    Suppression now happens inside NVDA, before anything is synthesised, via
;    the same sentinel mechanism MiniTray uses: a quiet window is opened
;    before the keystrokes go out and closed just before the confirmation is
;    spoken. Needs globalPlugins\conceptSphereQuiet.py installed. Without it
;    the sentinels are harmless -- a lone control character is not voiced --
;    and you simply hear the chatter again.

global g_NvdaDll := ""          ; module name for DllCall, "" when not loaded

QUIET_MS   := 900               ; quiet window opened around the keystrokes
SELECT_GAP := 60                ; ms between ^a and ^c
COPY_GAP   := 200               ; ms to let the "unselected" event be dropped

LoadNVDA()

^+a:: {
    global QUIET_MS, SELECT_GAP, COPY_GAP

    if !IsConsole() {
        ; Pass through untouched. {Blind} leaves the modifiers the user is
        ; already holding exactly as they are, so this path cannot strand one.
        Send "{Blind}a"
        return
    }

    ; Let go of the hotkey before injecting anything. This is the fix for the
    ; stuck Ctrl -- with no physical modifier down, AHK's send is symmetrical.
    KeyWait "a", "T1"
    KeyWait "Control", "T1"
    KeyWait "Shift", "T1"

    NvdaCancel()                ; kill anything mid-utterance
    NvdaQuiet(QUIET_MS)         ; open the quiet window BEFORE the keystrokes

    Send "^a"                   ; conhost select-all
    Sleep SELECT_GAP
    Send "^c"                   ; copy (also clears the selection)
    Sleep COPY_GAP              ; both announcements have been dropped by now

    ReleaseStuckModifiers()     ; belt and braces

    NvdaQuiet(0)                ; close the window, then say our piece
    NvdaSay("select all and copied to clipboard")
}

IsConsole() {
    cls := WinGetClass("A")
    return (cls = "ConsoleWindowClass" || cls = "CASCADIA_HOSTING_WINDOW_CLASS")
}

; Force up any modifier Windows still thinks is down while the physical key
; is not. Never touches a key the user is actually holding.
ReleaseStuckModifiers() {
    for key in ["LControl", "RControl", "LShift", "RShift",
                "LAlt", "RAlt", "LWin", "RWin"] {
        if (GetKeyState(key) && !GetKeyState(key, "P"))
            SendInput "{" key " up}"
    }
}

; ---------------------------------------------------------------- NVDA glue

LoadNVDA() {
    global g_NvdaDll
    for name in ["nvdaControllerClient64.dll", "nvdaControllerClient.dll"] {
        if DllCall("LoadLibrary", "Str", A_ScriptDir "\" name, "Ptr") {
            g_NvdaDll := SubStr(name, 1, -4)     ; drop ".dll"
            return
        }
    }
}

NvdaRunning() {
    return g_NvdaDll
        && DllCall(g_NvdaDll "\nvdaController_testIfRunning", "UInt") = 0
}

NvdaCancel() {
    if g_NvdaDll
        DllCall(g_NvdaDll "\nvdaController_cancelSpeech")
}

; Open (ms > 0) or close (ms = 0) a quiet window in conceptSphereQuiet.py.
; The plugin caps whatever is asked for, so a crash here cannot mute NVDA.
NvdaQuiet(ms) {
    if g_NvdaDll
        DllCall(g_NvdaDll "\nvdaController_speakText",
                "Str", Chr(1) "MTQUIET:" ms Chr(1))
}

NvdaSay(text) {
    if !NvdaRunning() {
        SoundBeep 900, 100        ; fallback if NVDA isn't up
        return
    }
    DllCall(g_NvdaDll "\nvdaController_speakText", "Str", text)
    DllCall(g_NvdaDll "\nvdaController_brailleMessage", "Str", text)
}
